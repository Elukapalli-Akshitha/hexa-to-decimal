def hexadecimal_to_decimal(hexadecimal_num):
    if not all(char.isdigit() or char.upper() in 'ABCDEF' for char in hexadecimal_num):
        return "Invalid input: not a hexadecimal number"
    hex_map={'0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7 ,
    '8': 8, '9': 9, 'A': 10, 'B': 11, 'C':12, 'D': 13, 'E': 14, 'F': 15}
    decimal_num=0 
    for i, digit in enumerate(reversed(hexadecimal_num)):
        decimal_num+=hex_map[digit.upper()]*(16**i)
    return decimal_num
hexadecimal_num=input() 
decimal_num=hexadecimal_to_decimal(hexadecimal_num)
print("Decimal:", decimal_num)